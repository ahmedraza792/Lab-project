package com.blackwell.utils;

/**
 * Names the colors of the cube facelets
 */
public enum Color {
	U, R, F, D, L, B
}
